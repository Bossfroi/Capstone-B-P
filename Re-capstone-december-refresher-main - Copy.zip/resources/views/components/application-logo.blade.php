<a href="/dashboard">
    <img src="b&p logo.jpg" alt="" height="100px" width="40px">
    </a>
