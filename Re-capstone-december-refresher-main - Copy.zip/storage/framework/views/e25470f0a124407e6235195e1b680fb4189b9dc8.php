<a href="/dashboard">
    <img src="b&p logo.jpg" alt="" height="100px" width="40px">
    </a>
<?php /**PATH C:\Users\PC\Desktop\Re-capstone-december-refresher-main\resources\views/components/application-mark.blade.php ENDPATH**/ ?>