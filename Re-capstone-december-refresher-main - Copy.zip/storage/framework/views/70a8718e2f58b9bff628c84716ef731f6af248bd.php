<a href="/">
<img src="b&p logo.jpg" alt="" height="200px" width="80px">
</a>
<?php /**PATH C:\Users\PC\Desktop\Re-capstone-december-refresher-main\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>