
<?php echo $__env->make('include/navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="bg-gray-100 min-h-screen py-8 m-28">
    <div class="container mx-auto p-4 m-28">
        <h1 class="text-3xl font-bold mb-6 text-center">News Headlines</h1>
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 m-28">
            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white p-4 m-28 rounded shadow transition transform hover:scale-105 hover:shadow-lg ">
                    <?php if($article['urlToImage']): ?>
                        <img src="<?php echo e($article['urlToImage']); ?>" alt="<?php echo e($article['title']); ?>" class="mb-4 " style="width: 750px; height:450px; margin-left:120px;">
                    <?php endif; ?>
                    <h2 class="text-lg font-semibold mb-2"><?php echo e($article['title']); ?></h2>
                    <p class="text-gray-700"><?php echo e($article['description']); ?></p>
                    <a href="<?php echo e($article['url']); ?>" target="_blank" rel="noopener noreferrer" class="text-blue-500 mt-4 inline-block hover:underline">
                        Read more
                    </a>
                </div>
                <hr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
        </div>
    </div>
    <?php echo $__env->make('include/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH C:\Users\PC\Desktop\Re-capstone-december-refresher-main\resources\views/pages/news.blade.php ENDPATH**/ ?>